import React,{Component} from 'react';
class Datedefault extends Component
{
    constructor()
    {
        super()
        this.state={
            date1:new Date().toISOString()
        }
    }
    render()
    {
        return(
            <div>
                <input type="date" value={this.state.date1}></input>
                
            </div>
        )
    }

}
export default Datedefault;