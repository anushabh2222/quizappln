import React from "react";
import { Redirect } from 'react-router-dom'
 class Loginstudent extends React.Component{

    constructor(){
        super()
        this.state = {
            regmsg : '',
            loginmsg : '',
            loginstatus : false,
            datas:[]
        }
    }

    login = (event)=>{
        var ob = {
            id : this.id.value
        }
        console.log(this.setState.loginstatus)
        fetch(`http://localhost:8080/api/login`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json"
            },
            body : JSON.stringify(ob)
        }).then(response=>response.json()).then(data=>{
            console.log(data)
            console.log(data.id)
            this.setState({regmsg:data.msg})
            if(data.status)
            {
                
                this.setState({loginstatus:true})
            }else
            this.setState({loginmsg:data.msg})
            
        });;
        console.log(this.state.loginstatus)
        console.log(ob)
        
        event.preventDefault()
    }

    render(){
        if(this.state.loginstatus){
            return(
            <Redirect to={"/takequiz"}/> )
        }
        return(
          <div>
          <h1>Student Login</h1>
          <div className="col-sm-6 offset-sm-3">
            <form method="post"  onSubmit={this.login} action="">
            <div class="row register-form">
                <div class="col-md-6">
                    <div class="form-group">
                        <input type="number" class="form-control" ref={c=>this.id=c} name="id" id="id" placeholder="id " required/>
                    </div>
                </div>
                <div class="col-md-6">
                    <input type="submit" className="btn btn-primary"name="adsub" value="Login"/>
                </div>
                <b style={{color:"red"}}>{this.state.regmsg}</b>
            </div>
        </form>
        </div>
        </div>
        )
    }

}
export default Loginstudent