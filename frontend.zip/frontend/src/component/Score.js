import { React, Component } from 'react';
import {Link} from 'react-router-dom'



class Score extends Component {
  constructor(){
    super();
    this.state = {
      act : 0,
      idx : '',
      datas : []
    }
  }
  render() {  
    return ( 
      <div className="App">
          <h1>your score is</h1>
          
      </div>
     );
  }
}
 
export default Score;