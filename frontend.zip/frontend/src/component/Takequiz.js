import { React, Component } from 'react';
import {Link} from 'react-router-dom'



class Takequiz extends Component {
  constructor(){
    super();
    this.state = {
      act : 0,
      idx : '',
      datas : []
    }
  }
  render() {  
    return ( 
      <div className="App">
          <h1>Take a Quiz</h1>
          <p>Good luck!</p>
         
        <Link to="/quiz">START</Link>
      </div>
     );
  }
}
 
export default Takequiz;