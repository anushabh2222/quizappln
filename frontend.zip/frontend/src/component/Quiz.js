import React from 'react';
import TimeConverter from './TimeConverter';



class Quiz extends React.Component {
  constructor() {
    super();
    this.state = {
      act: 0,
      idx: '',
      datas: [],
      questions: [],
      count:0,
      Results:[],
      sumofresults:0,
      resultsstutes:false
    }
  }

  

	
  
  
 
  
  
  option = (select,correct,index) => {
    
    
    console.log(select)
    console.log(correct)
    console.log(index);
    if(select===correct){
      console.log("1 point")
      this.state.Results.splice(index,1)
      this.state.Results.splice(index,0,10)
      console.log(this.state.Results)
      
    }
    else{
      this.state.Results.splice(index,1)
      this.state.Results.splice(index,0,0)
    }
    this.setState({sumofresults:this.state.Results.reduce((a , b) => a+b)})
    
}


  
  submitquiz= () => {
    this.setState({resultsstutes:true})
    console.log("your score is"+ this.state.sumofresults);
    

  }


  componentDidMount() {
    fetch('http://localhost:8080/question/studentlist')
      .then(response => response.json()).then(data => {
        console.log(data)
        this.setState({Results:new Array(data.length).fill(0)})
        this.setState({ questions: [...data] })
      }
      );
   setTimeout(this.submitquiz,600000)
  }

 

  render() {

    return (
        <>

        <div class="wrapper rounded bg-white justify-content-sm-center  ">
          {this.state.resultsstutes == false?<>
            <h2 style={{marginLeft:'0%',color:'green',height:"20%"}}><TimeConverter></TimeConverter></h2>
            <div class="h1">Answer the questions</div>
        
        
         
        {this.state.questions.map((data,index) =>
        <form>
        <div key={index}>    
        <div>
        <label >{index+1}.{data.question}</label>
        </div>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" onClick={()=>this.option(data.option1,data.correct,index)} name="inlineRadioOptions" id="inlineRadio1" value="option1" onChange={this.handleChange}/>
        <label class="form-check-label" for="inlineRadio1">{data.option1}</label>
        </div><br/>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" onClick={()=>this.option(data.option2,data.correct,index)} name="inlineRadioOptions" id="inlineRadio2" value="option2" onChange={this.handleChange}/>
        <label class="form-check-label" for="inlineRadio2">{data.option2}</label>
        </div><br/>

        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" onClick={()=>this.option(data.option3,data.correct,index)} name="inlineRadioOptions" id="inlineRadio3" value="option3" onChange={this.handleChange}/>
        <label class="form-check-label" for="inlineRadio3">{data.option3}</label>
        </div><br/>
        <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" onClick={()=>this.option(data.option4,data.correct,index)} name="inlineRadioOptions" id="inlineRadio4" value="option4" onChange={this.handleChange}/>
        <label class="form-check-label" for="inlineRadio4">{data.option4}</label>
        </div> <br/>     
        </div>
        </form> )}
        <button onClick={(this.submitquiz)}>submit</button></>:<>
        {this.state.sumofresults >= 70?
        <h1 style={{color:"green"}}> Yours score is  {this.state.sumofresults}</h1> :
        this.state.sumofresults >= 40?
        <h1 style={{color:"yellow"}}> Yours score is  {this.state.sumofresults}</h1>:

        <h1 style={{color:"red"}}> Yours score is  {this.state.sumofresults}</h1>}
        </>}
        

        </div>
       

      
        </>

        );
        }
        }
export default Quiz;