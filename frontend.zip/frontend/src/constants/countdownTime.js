const COUNTDOWN_TIME = {
  minutes: []

};



for (let i = 0; i <=10; i++) {
  COUNTDOWN_TIME.minutes.push({ key: i, text: i, value: i * 60 });
}


export default COUNTDOWN_TIME;
