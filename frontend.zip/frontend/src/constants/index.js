export { default as COUNTDOWN_TIME } from './countdownTime';
export { default as NUM_OF_QUESTIONS } from './numOfQuestions';

