package com.example.demo.model;

public class Quiztodo {
    private int questionid;
    private String questionname;
    private Questionoption options;
    public Quiztodo(Long id, String question, Questionoption questionoption) {
    }
    public int getQuestionid() {
        return questionid;
    }
    public void setQuestionid(int questionid) {
        this.questionid = questionid;
    }
    public String getQuestionname() {
        return questionname;
    }
    public void setQuestionname(String questionname) {
        this.questionname = questionname;
    }
    public Questionoption getOptions() {
        return options;
    }
    public void setOptions(Questionoption options) {
        this.options = options;
    }
    @Override
    public String toString() {
        return "Quiztodo [options=" + options + ", questionid=" + questionid + ", questionname=" + questionname + "]";
    }
    

    
}
