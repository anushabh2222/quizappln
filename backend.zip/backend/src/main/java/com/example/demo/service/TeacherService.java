package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Teacher;

public interface TeacherService {
    List<Teacher> getAllTeachers();
	Teacher findTeacherByUsername(String name);
    Teacher findTeacherById(String id);
	Teacher saveTeacher(Teacher teacher);
	Teacher getTeacherById(String id);
	Teacher updateTeacher(Teacher teacher);
	void deleteTeacherById(String Id);
}

    

