package com.example.demo.repositories;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.model.Question;
import org.springframework.stereotype.Repository;
@Repository
public interface QuestionRepository extends MongoRepository<Question, Long> {

    Question findQuestionById(Long id);
    void deleteById(Long Id);
	

    

}

