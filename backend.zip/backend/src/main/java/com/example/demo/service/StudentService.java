package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Student;

import org.springframework.stereotype.Service;

@Service
    public interface StudentService {
        List<Student> getAllStudents();
        Student findStudentById(String id);
        Student findStudentByName(String name);
        Student saveStudent(Student student);
        Student getStudentById(String id);
        Student updateStudent(Student student);
        void deleteStudentById(String Id);
        
    }
    