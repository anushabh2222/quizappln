package com.example.demo.controller;
import java.util.Collections;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.Response.Response;
import com.example.demo.model.Question;
import com.example.demo.repositories.QuestionRepository;
@RestController
@RequestMapping("/question")
@CrossOrigin
public class QuestionController {
	@Autowired
	QuestionRepository questionRepository;
	@PostMapping("/create")
	public Response createQuestion(@RequestBody Question question) {
		 questionRepository.insert(question);
		 return new Response("200"," created successfully ","data",true);
	}
	@GetMapping("/list")
	public List<Question> listQuestions(){
		List<Question> qlist =questionRepository.findAll();;
		return qlist;	
	}
	@GetMapping("/studentlist")
	public List<Question> studentlist(){
		List<Question> qlist =questionRepository.findAll();;
		Collections.shuffle(qlist);//shuffle of questions among all questions
		return qlist;	
	}
	@PutMapping("/update")
	public Response updatebyId(@RequestBody Question question) 
	{
		try{
			boolean existQuestion=questionRepository.existsById(question.getId());
			if(existQuestion){	
			questionRepository.save(question);
			return new Response("200","updated successfully","data",true);
		}
	}
	catch(Exception e){
		return new Response("500"," id not found","something went wrong",false);
	}
		return new Response("400"," not found","data",false);
	}
	@DeleteMapping("/delete/{id}")
	public Response deleteQuestion(@PathVariable Long id) {
	try
	{
		questionRepository.deleteById(id);
	}
	catch(Exception e){
		return new Response("400","not found",e,false);
	}
	return new Response("success","deleted successfully ",id,true);
	}
	

	

}
	
	


	
	
	
	


