package com.example.demo.service;
import java.util.ArrayList;
import java.util.List;

import com.example.demo.model.Question;
import com.example.demo.model.Questionoption;
import com.example.demo.model.Quiztodo;
import com.example.demo.repositories.QuestionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class QuizService {



@Autowired
private QuestionRepository repository;



public String saveQuiz(Question quiz) {
repository.save(quiz);
return "Quiz added" + quiz.getId();
}



public List<Quiztodo> getQuestion() {
    List<Quiztodo> quizto = new ArrayList<>();
    for (Question quiz : repository.findAll()) {
    Quiztodo quizDto = new Quiztodo(quiz.getId(), quiz.getQuestion(),
    new Questionoption(quiz.getOption1(), quiz.getOption2(), quiz.getOption3(), quiz.getOption4()));
    quizto.add(quizDto);
    }
    return quizto;
    }
    }


