import React  from 'react';

import './App.css';


import {Route} from "react-router-dom";
import  Student from './component/Student';
import NavBar from './component/NavBar';
import  Teacher from './component/Teacher';
import  Loginstudent from './component/Loginstudent';
import  Loginteacher from './component/Loginteacher';
import  Addquestion from './component/Addquestion';
import Takequiz from './component/Takequiz';
import Quiz from './component/Quiz';
import TimeConverter from './component/TimeConverter';
import Score from './component/Score';





function App() {
  return (
    <div className="App">
    
      
      
     
      <NavBar/>
      <Route  exact path="/Loginstudent/" component={Loginstudent}/> 
      <Route  exact path="/student" component={Student}/> 
      <Route  exact path="/Loginteacher/" component={Loginteacher}/> 
      <Route  exact path="teacher" component={Teacher}/> 
      <Route  exact path="/teacher" component={Teacher}/> 
      <Route  exact path="/addquestion" component={Addquestion}/> 
      <Route  exact path="/takequiz" component={Takequiz}/> 
      <Route  exact path="/quiz" component={Quiz}/> 
      <Route  exact path="/TimeConverter" component={TimeConverter}/> 
      <Route  exact path="/Score" component={Score}/> 
      
    </div>
    
  );
}

export default App;
