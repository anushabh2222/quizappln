import React from 'react';
import TimeConverter from './TimeConverter';
import {Link} from 'react-router-dom'
// import TimeConverter from './component/TimeConverter';
class Quiz extends React.Component {
  constructor() {
    super();
    this.state = {
      act: 0,
      idx: '',
      datas: [],
      questions: [],
    }
  }
  option = (select,correct) => {
    // console.log(document.getElementById(e.target.id).value)
    console.log(select)
    console.log(correct)
    

  }
  submitquiz= () => {
    console.log("your score is");
    

  }


  componentDidMount() {
    fetch('http://localhost:8080/question/list')
      .then(response => response.json()).then(data => {
        console.log(data)
        this.setState({ questions: [...data] })
      }
      );
    console.log(this.state.questions.map(a => a.question));
  }

 

  render() {

    return (<>


         
        <h2 style={{marginLeft:'0%',color:'green',height:"20%"}}><TimeConverter></TimeConverter></h2>
       

      <div class="wrapper rounded bg-white justify-content-sm-center  ">

        
        <div class="h1">Answer the questions</div>
        
        <div class="">
         
          {this.state.questions.map((data,index) =>
          <form>
             <div key={index}>
             
             
            <div>

              <label >{index+1}. {data.question}</label>

            </div>

             <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" onClick={()=>this.option(data.option1,data.correct)} name="inlineRadioOptions" id="inlineRadio1" value="option1" onChange={this.handleChange} />
              <label class="form-check-label" for="inlineRadio1">{data.option1}</label>
              </div><br/>

              <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" onClick={()=>this.option(data.option2,data.correct)} name="inlineRadioOptions" id="inlineRadio2" value="option2" onChange={this.handleChange}/>
              <label class="form-check-label" for="inlineRadio2">{data.option2}</label>
              </div><br/>

              <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" onClick={()=>this.option(data.option3,data.correct)} name="inlineRadioOptions" id="inlineRadio3" value="option3" onChange={this.handleChange}/>
              <label class="form-check-label" for="inlineRadio3">{data.option3}</label>
              </div><br/>
              <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" onClick={()=>this.option(data.option4,data.correct)} name="inlineRadioOptions" id="inlineRadio4" value="option4" onChange={this.handleChange} />
              <label class="form-check-label" for="inlineRadio4">{data.option4}</label>
              </div> <br/>
              
              </div>
          </form> )}
         <button onClick={(this.submitquiz)}> SUBMIT</button>
        </div>
        </div>

      
    </>

    );
  }
}
export default Quiz;