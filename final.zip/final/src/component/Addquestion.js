import { React, Component } from 'react';



class Addquestion extends Component {
  constructor(){
    super();
    this.state = {
      act : 0,
      idx : '',
      datas : []
    }
  }

  componentDidMount(){
    fetch('http://localhost:8080/question/list')
    .then(response=>response.json()).then(data=>{
      console.log(data)
      this.setState({datas:data})
      

       }
    );
  } 
  handleSubmit=(e)=>{
    e.preventDefault();
    let datas = this.state.datas;
    let id = this.refs.id.value;
    let question = this.refs.question.value;
    let option1 = this.refs.option1.value;
    let option2 = this.refs.option2.value;
    let option3 = this.refs.option3.value;
    let option4= this.refs.option4.value;
    let correct= this.refs.correct.value;
    
    


    if(this.state.act === 0)
    {
      let data = {
        "id":id,
        "question":question,
        "option1" : option1,
        "option2" : option2,
        "option3":  option3,
        "option4":  option4,
        "correct":correct

      }

      datas.push(data);
      fetch(`http://localhost:8080/question/create`,{
            method : 'POST',
            headers:{
                "Content-Type" : "application/json"
            },
            body : JSON.stringify(data)
        }).then(response=>response.json()).then(data=>{
            console.log(data)
            
        });

    
}
    else
    {
        let index = this.state.idx;
        datas[index].id = id;
        datas[index].question = question;
        datas[index].option1 = option1;
        datas[index].option2 = option2;    
        datas[index].option3 = option3;
        datas[index].option4 = option4;
        datas[index].correct = correct;

        let data = {
            "id":id,
            "question":question,
            "option1" : option1,
            "option2" : option2,
            "option3":  option3,
            "option4":  option4,
            "correct":correct,
        }  
        fetch(`http://localhost:8080/question/update`,{
            method : 'PUT',
            headers:{
                "Content-Type" : "application/json"
            },
            body : JSON.stringify(data)
        }).then(response=>response.json()).then(data=>{
            console.log(data)
            let updatedQuestions=[this.state.addquestion];
    this.setState({addquestion:updatedQuestions});
            
        });

}       
    
    
    
    this.setState({
      datas : datas,
      act : 0
    })
    this.refs.myForm.reset();
    this.refs.question.focus();
  }

  handleDelete = (index,obj) =>{
    let datas = this.state.datas;
    datas.splice(index,1);
    this.setState({
      datas:datas
    })
    this.refs.id.focus();
   fetch(`http://localhost:8080/question/delete/${obj.id}`,{
    method:'DELETE',
    
  }) .then(response=>response.json()).then(data=>{
    console.log(data)
  });
  }
  
async remove(id)
{
  console.log(id)
  
  let updatedQuestions=[this.state.addquestion].filter(i=>i.id!==id);
  this.setState({addquestion:updatedQuestions});
  

}




  handleEdit = (index) => {
    let data = this.state.datas[index];
    this.refs.id.value = data.id;
    this.refs.question.value = data.question;
    this.refs.option1.value = data.option1;
    this.refs.option2.value = data.option2;
    this.refs.option3.value = data.option3;
    this.refs.option4.value = data.option4;
    this.refs.correct.value = data.correct;

    this.setState({
      act: 1,
      idx : index
    })
    
  }
  
  
  render() { 
   
    
    let datas = this.state.datas;
    return ( 
      <div className="App">
      
        <form ref="myForm" className="myForm">
        <h1>{this.state.title}</h1>
        <h2>Add Questions</h2>
        <label>Question no</label>
          <input type="number" ref="id" placeholder="Enter the question number" className="formField"/>
          <label>Question</label>
          <input type="text" ref="question" placeholder="Enter the question" className="formField"/>
          <label>Option1</label>
          <input type="text" ref="option1" placeholder="Enter option1" className="formField"/>
          <label>Option2</label>
          <input type="text" ref="option2" placeholder="Enter option2"  className="formField"/>
          <label>Option3</label>
          <input type="text" ref="option3" placeholder="Enter option3" className="formField"/>
          <label>Option4</label>
          <input type="text" ref="option4" placeholder="Enter option4" className="formField"/>
          <label>Answer</label>
          <input type="text" ref="correct" placeholder="Enter answer" className="formField"/>
          
          <button onClick={e => this.handleSubmit(e)} className="myButton"> Save</button>
        </form>
        <br/>
        <br/>
        <table className="table">
          <tr>
            <th>question no</th>
            <th>question</th>
            <th>Option1</th>
            <th>Option2</th>
            <th>Option3</th>
            <th>Option4</th>
            <th>Answer</th>
            <th>Delete</th>
            <th>Update</th>

          </tr>
          
       

        
          {this.state.datas.map((data,index)=>
            <tr key={index}>  
            <td>{data.id}</td>
            <td>{data.question}</td>
            <td>{data.option1}</td>
            <td>{data.option2}</td>
            <td>{data.option3}</td>
            <td>{data.option4}</td>
            <td>{data.correct}</td>
            <td>
            <button onClick={e => this.handleDelete(index,data)} className="myListButton">Delete</button>
            </td>
            <td>
            <button onClick={e => this.handleEdit (index)} className="myListButton">Update</button>
            </td>
            </tr>
            )
          }
          
     
        </table>
      </div>
     );
  }
}
 
export default Addquestion;